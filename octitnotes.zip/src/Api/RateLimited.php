<?php

namespace Cloudinary\Api;

/**
 * Class RateLimited
 * @package Cloudinary\Api
 */
class RateLimited extends Error
{
}
