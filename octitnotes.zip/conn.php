<?php
$con=mysqli_connect("localhost","id8566641_octitnotes","octitnotes","id8566641_octitnotes");
if($con!=TRUE)
{
    echo ("database not connected");
}

?>